package com.accenture.bootcamp.day1

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import java.io.File
object Loader {

  protected def fromResource(resource: String): String = {
    new File(new File("src/test/resources/" + resource).getCanonicalPath)
      .toURI.toString
  }

  def loadNewYearHonours(sc: SparkContext): RDD[String] = {
    // TODO Task #1: Create RDD from file `1918NewYearHonours.txt`

    val filePath = fromResource("1918NewYearHonours.txt")
    val DataRDD = sc.textFile(filePath)
    DataRDD
  }

  def loadAustralianTreaties(sc: SparkContext): RDD[String] = {
    // TODO Task #2: Create RDD from file `ListOfAustralianTreaties.txt`
    val filePath = fromResource("ListOfAustralianTreaties.txt")
    val dataRDD2 = sc.textFile(filePath)
    dataRDD2
  }


}
